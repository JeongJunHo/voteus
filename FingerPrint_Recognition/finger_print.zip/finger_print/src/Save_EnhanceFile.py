from src.utils import *
import time
from src.constants import ENHANCE_PATH
from src.constants import IMAGES_PATH
from PIL import Image


def save_EnhanceFile(file_names):
    temp_label = get_image_class(file_names[0])
    cnt = 1
    for filename in file_names:
        if cnt is 11:
            cnt = 1
        #img = Image.open(filename)
        #img.save()
        label = get_image_label(filename)
        tmpgo = format(label).split("_")[0]

        img = cv2.imread(filename)
        img = cv2.resize(img, dsize=(296, 560), interpolation=cv2.INTER_LINEAR)

        gray_img = grayscale_image(img)
        img_blur = cv2.GaussianBlur(gray_img, (1, 1), 0)

        img_e = enhance_image(img_blur)

        #ret, dst = cv2.threshold(gray_img, 25, 255, cv2.THRESH_BINARY)

        #dst =  cv2.adaptiveThreshold(img_blur, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 21, 10)
        #dst = enhance_image(img_blur)
        cv2.imwrite(ENHANCE_PATH + '/' + tmpgo+'_'+str(cnt)+'.bmp', img_e)

        #cv2.imwrite(ENHANCE_PATH+'/'+format(label),img)
        cnt = cnt+1

    #     print('Processing image {} ...  '.format(label))
    #     if temp_label != get_image_class(filename):
    #         train, test = split_dataset(data, 0.2)
    #         train_set.update(train)
    #         test_set.update(test)
    #         temp_label = get_image_class(filename)
    #         data = []
    #     data.append((label, img))
    #     print('label image 22 : ')
    #     print(time.time() - starttime)
    #     starttime = time.time()
    #     if filename == file_names[len(file_names) - 1]:
    #         train, test = split_dataset(data, 0.2)
    #         train_set.update(train)
    #         test_set.update(test)
    #
    # print('DONE')
    # return train_set, test_set


def process_Enhance(file_names):
    train_set = {}
    test_set = {}
    data = []  # list of tuples
    temp_label = get_image_class(file_names[0])  # sets the image class (101)


    for filename in file_names:
        print(filename)
        label = get_image_label(filename)
        img = cv2.imread(filename)
        print('Processing image {} ...  '.format(label))
        if temp_label != get_image_class(filename):
            train, test = split_dataset(data, 0.2)
            train_set.update(train)
            test_set.update(test)
            temp_label = get_image_class(filename)
            data = []
        data.append((label, img))

        if filename == file_names[len(file_names) - 1]:
            train, test = split_dataset(data, 0.2)
            train_set.update(train)
            test_set.update(test)

    return train_set, test_set
