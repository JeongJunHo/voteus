from src.utils import *
import cv2
from src.constants import PATH_TO_ROOT

#path = '/data/Real/100__M_Left_little_finger.BMP'
path = PATH_TO_ROOT + '\data\Real\\100__M_Left_little_finger.BMP'
print(path)
img = cv2.imread(path)
#print(img)
grayimg = grayscale_image(img)

cv2.imshow("asdf", grayimg)
cv2.waitKey(0)
cv2.destroyAllWindows()