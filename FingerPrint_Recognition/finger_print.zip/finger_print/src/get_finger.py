'''
지문을 얻어서 그 결과를 보여주기위한 코드..
2020.02.06
박종수

'''

import operator

from src.constants import *
from src.preprocessing import *
from src.plots import *

from sklearn.metrics import accuracy_score

# pyeer library: pip install pyeer

#In[2]
#image_files = read_images()
image_files = read_enhances()

print(image_files)

#In[3]
train_set, test_set = prepare_dataset(image_files)

#ln[4]
print('Size of the training set:', len(train_set))
print('Size of the test set:', len(test_set))
#print(train_set.values())

#ln[5]
# Initiate ORB detector for matching keypoints
orb = cv2.ORB_create(MAX_FEATURES)
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)


#ln[6]
plt.subplot(1, 2, 1)
plt.title('Before enhancement')
img_fpr = cv2.imread(image_files[0])
plt.imshow(img_fpr, cmap='gray')
plt.subplot(1, 2, 2)
plt.title('After enhancement')
plt.imshow(train_set['101_1.tif'], cmap='gray')
plt.show()

#ln[7]
# Returns feature descripors for all images from the dataset
def get_feature_descriptors(dataset):
    feature_descriptors = {}
    for image_id, image in dataset.items():
        image = np.array(image, dtype=np.uint8)
        kp, des = orb.detectAndCompute(image, None)
        feature_descriptors[image_id] = des
    return feature_descriptors

#ln[8]
# Returns best_matches between training features descriptors and query image
def get_best_matches(query_image, trained_features, distance_threshold):
    best_matches_dict = {}
    query_image = np.array(query_image, dtype=np.uint8)
    kp1, query_des = orb.detectAndCompute(query_image, None)  # features of the query image
    for train_image_id, trained_feature_des in trained_features.items():
        if query_des is not None and trained_feature_des is not None:
            matches = bf.match(query_des, trained_feature_des)
            matches.sort(key=lambda x: x.distance, reverse=False)  # sort matches based on feature distance

            best_matches = [m.distance for m in matches if m.distance < distance_threshold]
            best_matches_dict[train_image_id] = len(
                best_matches)  # matching function = length of best matches to given threshold

    best_matches_dict = sorted(best_matches_dict.items(), key=operator.itemgetter(1),
                               reverse=True)  # sort by value - feature distance
    return best_matches_dict


#ln[10]
# Apply homography to test and train image
# Homography or image alignment: to perfectly line up the features in two images
def apply_homography(query_image, closest_image):
    query_image = np.array(query_image, dtype=np.uint8)
    closest_image = np.array(closest_image, dtype=np.uint8)
    kp1, des1 = orb.detectAndCompute(query_image, None)
    kp2, des2 = orb.detectAndCompute(closest_image, None)
    matches = bf.match(des1, des2)

    # Apply homography
    numGoodMatches = int(len(matches) * GOOD_MATCH_PERCENT)
    matches = matches[:numGoodMatches]

    src_pts = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
    dst_pts = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)

    # M matrix that represents the homography
    M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)

    # Use homography
    height, width = query_image.shape[:2]
    # The function warpPerspective transforms the source image using the specified matrix
    im1Reg = cv2.warpPerspective(closest_image, M, (width, height))

    # Plot aligned query and train image
    plt.subplot(1, 2, 1)
    plt.imshow(im1Reg, cmap='gray')
    plt.subplot(1, 2, 2)
    plt.imshow(query_image, cmap='gray')
    plt.show()

#ln[11]
from collections import defaultdict


def classify_fpr(best_matches_dict, rank):
    '''
    Counts how many fprs from the same class are there in the first ranked
    :param feature_distances: Feature distaces from given query fpr to all training fprs
    :param rank: To take the first ranked closest features
    :return first_rank_sorted: dictionary, where key denotes the fpr class and
            the value is how many times it appears in the first ranked fprs
    '''
    first_rank_fprs = defaultdict(int)
    for fpr_name, distance in best_matches_dict[0:rank]:
        fpr_class = get_image_class(fpr_name)
        first_rank_fprs[fpr_class] += 1

    first_rank_sorted = sorted(first_rank_fprs.items(), key=operator.itemgetter(1), reverse=True)
    return first_rank_sorted

#ln[12]
def draw_keypoints_matches(fpr1, fpr2):
    fpr1 = np.array(fpr1, dtype=np.uint8)
    fpr2 = np.array(fpr2, dtype=np.uint8)
    kp1, des1 = orb.detectAndCompute(fpr1, None)
    kp2, des2 = orb.detectAndCompute(fpr2, None)

    matches = bf.match(des1, des2)
    matches.sort(key=lambda x: x.distance, reverse=False)
    imMatches = cv2.drawMatches(fpr1, kp1, fpr2, kp2,matches[:10], None)

    plt.imshow(imMatches)
    plt.show()


#Identification scenario
#ln[31]
train_feature_descriptors = get_feature_descriptors(train_set)
#print(train_feature_descriptors)


#ln[30]
# Definition of identification scenario
def perform_identification_scenario(dist_threshold, rank, should_draw):
    true_y = []
    pred_y = []
    total_prob = 0
    print("----- START, threshold = {}, rank = {} -----".format(dist_threshold, rank))
    for test_image_id, test_image in test_set.items():
        # Get the distances between the query image and all other training images
        # print(test_image)
        best_matches_dict = get_best_matches(test_image, train_feature_descriptors, dist_threshold)
        true_class = get_image_class(test_image_id)

        # Classify the first closest features according to the given rank
        first_rank_fprs = classify_fpr(best_matches_dict, rank)
        # print(first_rank_fprs)
        predicted_class = first_rank_fprs[0][0]
        prob = first_rank_fprs[0][1] / TRAIN_PER_CLASS
        total_prob += prob
        true_y.append(true_class)  # true_class
        pred_y.append(predicted_class)

        if should_draw:  # Check whether to draw the homography and the matching keypoints
            closest_img_id = best_matches_dict[0][0]
            closest_img = train_set.get(closest_img_id)
            apply_homography(test_image, closest_img)  # image alignment
            draw_keypoints_matches(test_image, closest_img)
            print('Query fingerprint ID: ' + test_image_id)
            print('Best matching fingerprint ID: ' + closest_img_id)

    avg_probability = total_prob / len(test_set)
    print("Averaged probability for rank %d and threshold %d is %f " % (rank, dist_threshold, avg_probability))
    print("Accuracy for rank %d and threshold %d is %f " % (rank, dist_threshold, accuracy_score(true_y, pred_y)))
    return avg_probability

#ln[16]
rank = 3
for dist_threshold in range(20, 70, 10):
    perform_identification_scenario(dist_threshold, rank, False)

#ln[17]
dist_threshold = 50
avg_probabilities = []
rank_range = range(1, 10, 1)
for rank in rank_range:
    avg_probabilities.append(perform_identification_scenario(dist_threshold, rank, False))

