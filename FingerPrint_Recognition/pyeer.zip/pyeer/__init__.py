# -*- coding:utf-8 -*-

__copyright__ = 'Copyright 2017'
__author__ = u'Bsc. Manuel Aguado Martínez'
